SLA-JEC manuscript revised 2 October 2026.
Compile manuscript.tex twice with pdflatex using the supplied bbl.
Editable pipeline and vector figure sources are in editable_figures/.
Project: https://panzerjagerwang.github.io/camc-jl-structured-correction/
