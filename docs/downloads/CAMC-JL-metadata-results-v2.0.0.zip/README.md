CAMC-JL metadata and numerical-results dataset, version 2.0.0.
See DATASET_CARD.md and DATA_LICENSE.md. Scores are numerical; no learner text is included.
To reproduce results, install numpy==2.3.1 and run python scripts/reproduce_results.py.
